package com.company;

public abstract class Car {
    EngineBehavior engine;

    private int speed;

    public void startCar(){
        this.engine.carMoves();
    }

    public EngineBehavior getEngine() {
        return engine;
    }

    public void setEngine(EngineBehavior engine) {
        this.engine = engine;
    }

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }
}
