package com.company;

public class MercedesBenz extends Car{
    public MercedesBenz(){
        setSpeed(240);
        setEngine(new GasEngineBehavior());
    }

    public void startMercedesBenz(){
        System.out.println("This is Mercedes Benz car...");
        startCar();
    }
}
