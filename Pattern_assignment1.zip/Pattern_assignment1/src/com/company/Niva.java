package com.company;

public class Niva extends Car{
    public Niva(){
        setSpeed(180);
        setEngine(new DieselEngineBehavior());
    }

    public void startNiva() {
        System.out.println("This is Niva car...");
        startCar();
    }
}
