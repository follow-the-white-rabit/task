package com.company;

public class FutureCar extends Car{
    public FutureCar(){
        setSpeed(520);
        setEngine(new JetEngineBehavior());
    }

    public void startFutureCar(){
        System.out.println("This is car of the Future...");
        startCar();
    }
}
