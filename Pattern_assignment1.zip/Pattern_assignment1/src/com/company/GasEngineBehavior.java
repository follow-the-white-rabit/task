package com.company;

public class GasEngineBehavior implements EngineBehavior{
    @Override
    public void carMoves() {
        System.out.println("I am a car with Gas Engine and I am moving...");
        System.out.println("=============================================");
        System.out.println();
    }
}
