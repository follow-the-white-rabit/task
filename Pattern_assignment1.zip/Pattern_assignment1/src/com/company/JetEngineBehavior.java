package com.company;

public class JetEngineBehavior implements EngineBehavior{
    @Override
    public void carMoves() {
        System.out.println("I am a car with Jet Engine and I am really cool and I am moving...");
        System.out.println("==================================================================");
        System.out.println();
    }
}
