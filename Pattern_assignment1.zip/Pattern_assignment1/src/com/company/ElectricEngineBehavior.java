package com.company;

public class ElectricEngineBehavior implements EngineBehavior{
    @Override
    public void carMoves() {
        System.out.println("I am electric car and I am moving...");
        System.out.println("====================================");
        System.out.println();
    }
}
