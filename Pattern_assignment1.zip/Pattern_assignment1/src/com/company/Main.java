package com.company;

public class Main {

    public static void main(String[] args) {
	    MercedesBenz mercedes = new MercedesBenz();
        Niva niva = new Niva();
        Tesla tesla = new Tesla();
        FutureCar futureCar = new FutureCar();

	    mercedes.startMercedesBenz();
	    mercedes.setEngine(new ElectricEngineBehavior());
	    mercedes.startMercedesBenz();

        niva.startNiva();
        niva.setEngine(new GasEngineBehavior());
        niva.startNiva();

        tesla.startTesla();
        tesla.setEngine(new JetEngineBehavior());
        tesla.startTesla();

        futureCar.startFutureCar();
    }
}
