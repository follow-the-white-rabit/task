package com.company;

public class Tesla extends Car{
    public Tesla(){
        setSpeed(240);
        setEngine(new ElectricEngineBehavior());
    }

    public void startTesla(){
        System.out.println("This is Tesla car...");
        startCar();
    }
}
