package com.company;

public interface EngineBehavior {
    void carMoves();
}
