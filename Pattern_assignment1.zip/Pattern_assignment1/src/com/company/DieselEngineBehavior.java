package com.company;

public class DieselEngineBehavior implements EngineBehavior{
    @Override
    public void carMoves() {
        System.out.println("I am a car with Diesel Engine and I am moving...");
        System.out.println("================================================");
        System.out.println();
    }
}
